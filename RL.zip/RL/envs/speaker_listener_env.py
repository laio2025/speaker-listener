from mpe2 import simple_speaker_listener_v4

def make_speaker_listener_env(continuous=True, render=False):
    """
    Returns a single parallel MPE2 speaker-listener environment.
    """
    return simple_speaker_listener_v4.parallel_env(
        continuous_actions=continuous,
        render_mode="rgb_array" if render else None
    )
